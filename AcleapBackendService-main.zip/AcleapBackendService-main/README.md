# AcleapBackendService
This Backend Service is to connect the Azure Health data FHIR services with ACleap Application
