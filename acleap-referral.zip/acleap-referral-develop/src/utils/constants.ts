export enum ReferralStatus {
    Assigned = "Assigned",
    Completed = "Completed",
    Contact_unsuccessful = "Contact unsuccessful",
    Entered_in_error = "Entered in error",
    In_progress = "In progress",
    On_hold = "On hold",
    Received = "Received",
    Rejected = "Rejected",
    Service_not_needed = "Service not needed"
}
