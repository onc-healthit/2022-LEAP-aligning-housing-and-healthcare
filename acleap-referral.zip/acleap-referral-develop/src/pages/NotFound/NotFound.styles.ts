import { styled } from "@mui/material";

export const NotFoundContainer = styled("div")``