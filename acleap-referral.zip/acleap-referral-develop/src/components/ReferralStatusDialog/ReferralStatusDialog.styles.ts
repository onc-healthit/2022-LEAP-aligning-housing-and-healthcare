import { styled } from "@mui/material";

export const ReferralStatusModalContainer = styled("div")``
