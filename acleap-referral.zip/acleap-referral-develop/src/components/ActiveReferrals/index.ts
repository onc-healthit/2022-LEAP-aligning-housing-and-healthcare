import ActiveReferrals from "./ActiveReferrals";

export default ActiveReferrals
