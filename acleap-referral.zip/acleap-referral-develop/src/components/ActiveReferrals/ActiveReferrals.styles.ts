import { styled } from "@mui/material";

export const ActiveReferralsContainer = styled("div")``