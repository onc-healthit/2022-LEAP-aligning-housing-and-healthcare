import ReferralsCreation from "./ReferralsCreation";

export default ReferralsCreation