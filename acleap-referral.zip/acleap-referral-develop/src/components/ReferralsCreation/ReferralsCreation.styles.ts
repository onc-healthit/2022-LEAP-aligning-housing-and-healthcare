import { styled } from "@mui/material";

export const ReferralsCreation = styled("div")``