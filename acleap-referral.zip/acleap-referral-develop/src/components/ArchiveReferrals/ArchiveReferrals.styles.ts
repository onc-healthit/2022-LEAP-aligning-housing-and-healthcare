import { styled } from "@mui/material";

export const ArchiveReferralsContainer = styled("div")``