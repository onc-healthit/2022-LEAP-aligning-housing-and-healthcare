import ArchiveReferrals from "./ArchiveReferrals";

export default ArchiveReferrals
