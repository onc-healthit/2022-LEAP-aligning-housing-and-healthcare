import { styled } from "@mui/material";

export const PatientSearchContainer = styled("div")``