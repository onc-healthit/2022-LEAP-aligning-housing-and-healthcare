import PatientSearch from "./PatientSearch";

export default PatientSearch