import { styled } from "@mui/material";

export const PatientCreationContainer = styled("div")``