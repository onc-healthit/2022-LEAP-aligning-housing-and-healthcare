import PatientCreation from "./PatientCreation";

export default PatientCreation