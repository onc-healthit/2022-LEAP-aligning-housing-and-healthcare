import NewReferrals from "./NewReferrals";

export default NewReferrals