import { styled } from "@mui/material";

export const NewReferralsContainer = styled("div")``