import PatientModal from "./PatientModal";

export default PatientModal