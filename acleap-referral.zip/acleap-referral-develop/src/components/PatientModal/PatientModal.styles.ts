import { styled } from "@mui/material";

export const PatientModal = styled("div")``